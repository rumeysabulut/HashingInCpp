//
//  main.cpp
//  Project3
//
//  Created by Rumeysa Bulut on 29.11.2017.
//  Copyright © 2017 Rumeysa Bulut. All rights reserved.
//

#include <iostream>
#include "Dictionary.hpp"
#include "List.hpp"
int main(int argc, const char * argv[]) {
    cout << "DICTIONARY" << endl;
    Dictionary dict = Dictionary();
    cout << "LIST" << endl;
    List newlist = List();
    return 0;
}
